App.Views.trafficCalming = Object.create(App.BaseView);

App.Views.trafficCalming.mapInit = function() {

};

App.Views.trafficCalming.mapRender = function() {

};

App.Views.trafficCalming.mapClose = function() {

};

App.Views.trafficCalming.chartInit = function() {

};

App.Views.trafficCalming.chartRender = function() {

};

App.Views.trafficCalming.chartClose = function() {

};
