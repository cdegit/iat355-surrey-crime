App.Views.parking = Object.create(App.BaseView);

App.Views.parking.mapInit = function() {

};

App.Views.parking.mapRender = function() {

};

App.Views.parking.mapClose = function() {

};

App.Views.parking.chartInit = function() {

};

App.Views.parking.chartRender = function() {

};

App.Views.parking.chartClose = function() {

};
